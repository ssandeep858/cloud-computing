package simulator;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class decrypt{

	
	private static Cipher dcipher;

	

	public  void main(String ivx,String filename,String decfile) {

		try {
		//String ivx="c2bk4xkwdx5h 1ek";
			SecretKeySpec keySpec = new SecretKeySpec(ivx.getBytes(), "AES");
			IvParameterSpec ivSpec = new IvParameterSpec(ivx.getBytes());
			 dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
			
	decrypt(new FileInputStream(filename), new FileOutputStream(decfile));

		}
		catch (FileNotFoundException e) {
			System.out.println("File Not Found:" + e.getMessage());
			return;
		}
		catch (InvalidAlgorithmParameterException e) {
			System.out.println("Invalid Alogorithm Parameter:" + e.getMessage());
			return;
		}
		catch (NoSuchAlgorithmException e) {
			System.out.println("No Such Algorithm:" + e.getMessage());
			return;
		}
		catch (NoSuchPaddingException e) {
			System.out.println("No Such Padding:" + e.getMessage());
			return;
		}
		catch (InvalidKeyException e) {
			System.out.println("Invalid Key:" + e.getMessage());
			return;
		}

	}

	

	private static void decrypt(InputStream is, OutputStream os) {

  try {

  	byte[] buf = new byte[1024];

// bytes read from stream will be decrypted

  	CipherInputStream cis = new CipherInputStream(is, dcipher);

// read in the decrypted bytes and write the clear text to out

int numRead = 0;

while ((numRead = cis.read(buf)) >= 0) {

    os.write(buf, 0, numRead);

}

// close all streams

cis.close();

is.close();

os.close();

  }

  catch (IOException e) {

  	System.out.println("I/O Error:" + e.getMessage());

  }

    }

}