package simulator;

import java.math.*;
import java.util.*;

public class Tools
{
  public static int[] selectPrimes(int ulimit)
  {
    BigInteger no;
    String tmp;
    int i;
    Vector plist = new Vector();
    for(i=1;i<=ulimit;i++)
    {
      no = new BigInteger(""+i);
      if(no.isProbablePrime(8))
        plist.add(""+i);
    }

    int pnos[] = new int[plist.size()];
    for(i=0;i<plist.size();i++)
    {
      tmp = (String) plist.get(i);
      pnos[i] = Integer.parseInt(tmp);
    }
    return(pnos);
  }

  // Methods to select the fibonoacci numbers upto the upper limit
  public static int[] selectFibos(int ulimit)
  {
    String tmp;
    Vector flist = new Vector();
    int f1 = -1;
    int f2 = 1;
    int f;
    do
    {
      f = f1 + f2;
      f1 = f2;
      f2 = f;
      flist.add(""+f);
    }while((f1+f2)<=ulimit);

    int fnos[] = new int[flist.size()];
    for(int i=0;i<flist.size();i++)
    {
      tmp = (String) flist.get(i);
      fnos[i] = Integer.parseInt(tmp);
    }
    return(fnos);
  }
}
