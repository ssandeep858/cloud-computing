package simulator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;


public class concatfiles {

    public static void main(String args[])
    {
         try
         {
    Reader fileReader1 = new BufferedReader(new FileReader("c:/map1.txt"));
     Reader fileReader2 = new BufferedReader(new FileReader("c:/map2.txt"));
      Reader fileReader3 = new BufferedReader(new FileReader("c:/map3.txt"));
   int count=0;
   String str="";
       File file1 = new File("c:/map1.txt");
   File file2 = new File("c:/map2.txt");
      File file3 = new File("c:/map3.txt");
       File file4 = new File("c:/map4.txt");
      File file5 = new File("c:/map5.txt");
  
      long fileSizeInBytes1 = file1.length();
    long fileSizeInBytes2 = file2.length();
     long fileSizeInBytes3 = file3.length();
    long fileSizeInBytes4 = file4.length();
     long fileSizeInBytes5 = file5.length();
    System.out.print(fileSizeInBytes1+fileSizeInBytes2+fileSizeInBytes3+fileSizeInBytes4+fileSizeInBytes5);
     
     while (count < fileSizeInBytes1){ 
    
   str += (char)fileReader1.read() ;
   count++;

  }
     count=0;
      while (count < fileSizeInBytes2)
      { 
    
   str += (char)fileReader2.read() ;
   count++;

     }
     
     
   count=0;
      while (count < fileSizeInBytes3)
      { 
    
   str += (char)fileReader3.read() ;
   count++;

  }
   System.out.print(str); 
     
     
     
         }
         catch (IOException e)
         {
  // TODO Auto-generated catch block
         }
  
   }
    
    }

