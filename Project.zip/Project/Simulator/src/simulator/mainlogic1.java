/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.*;

public class mainlogic1 {
   public static String fn1=""; 
public static String str="";
    public static void main(String key,String fn)
    {
     
  try{
       Class.forName("com.mysql.jdbc.Driver");
Connection   connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/simulator","root","1234");
	Statement  smt = connection.createStatement();       
       int i=0;
ResultSet rs=smt.executeQuery("select * from storage where filenam='"+fn+"' and key_value='"+key+"' order by file_no asc");
while(rs.next())
{ i++;
fn1=fn;
    String k=rs.getString(3);
    String encfilenm=rs.getString(1);
    File f=new File(encfilenm);
    String name=f.getName();
  int l=name.length();
String  n=name.substring(0,l-4);

  decrypt obj1=new decrypt();
        obj1.main(k,encfilenm,"c:/temp/"+n+".txt");
        concat("c:/temp/"+n+".txt");
        
}
if(i==0)
{
    System.out.print("Finger prints not matched");
}
  } 
        catch(Exception o)
        {} 
   }
  
    
    static void concat(String content)
{
 try
         {
    Reader fileReader1 = new BufferedReader(new FileReader(content));
   
   int count=0;
   
       File file1 = new File(content);
   
  
      long fileSizeInBytes1 = file1.length();
   
     
     while (count < fileSizeInBytes1)
     { 
    str += (char)fileReader1.read() ;
    count++;
      }
    fileReader1.close();
  file1.delete();
         }
   
         catch (IOException e)
         {
  // TODO Auto-generated catch block
         }
  store(str,"c:/temp/"+fn1);
  
   }
    
    static void store(String content,String path)
{
try{
 
			File file = new File(path);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();
 
			System.out.println("Done");
 
		        } catch (IOException e) {
			e.printStackTrace();
		         }

}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
