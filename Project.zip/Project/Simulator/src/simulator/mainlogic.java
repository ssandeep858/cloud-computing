/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.*;

public class mainlogic {
    
    public  void main(String key,String fn)
    {
          int p=0;
String fnm="";
        String n="";      
   try{
       Class.forName("com.mysql.jdbc.Driver");
Connection   connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/simulator","root","1234");
	Statement  smt = connection.createStatement();       
       
          String a[]=new String[20];    
  
//String key="c2bk4xkwdx5h 1ek";        
        long no_of_files=0;
       File file = new File(fn);
fnm=file.getName();
// Get length of file in bytes
long fileSizeInBytes = file.length();
System.out.println(fileSizeInBytes);
if(fileSizeInBytes>200)
{
    no_of_files=fileSizeInBytes/200;
    long d=fileSizeInBytes%200;
    if (d>0)
    {
     no_of_files=no_of_files+1;   
    }
}   
  System.out.println(no_of_files);  
  
  String str="";
  int count=0;
  try {
  Reader fileReader = new BufferedReader(new FileReader(fn));
  String name=file.getName();
  int l=name.length();
  n=name.substring(0,l-4);
  while (count < fileSizeInBytes)
  { 
    
   str += (char)fileReader.read() ;
   count++;

  }
  
  //...............................
 
          ResultSet rs=smt.executeQuery("select * from servers");
    
       
          while(rs.next())
          {
        
         a[p]=rs.getString(2);
          p++;
          }
 fileReader.close();
       }
       catch(Exception obj)
       {
  System.out.println(obj.getMessage());
       }
   //......................................................
  
  
  
  String str1="";
  int end=0,i;
  int h=0;
  int x=1;
  for ( i=1;i<=no_of_files-1;i++)
  {

      
      if(x>p-1)
      {
          x=1;
          
      }
      int beg=((i-1)*200+h);
      end=200*i+1;
    str1=str.substring(beg,end);
  
 
  System.out.println(beg); // send str to another function and do something with it;
 System.out.println(end);
String path=a[x-1]+n+i+".txt";

store(str1,path);
aes obj=new aes();
        obj.main(key,path,a[x-1]+n+i+".dat");
        String q=a[x-1];
String enc=a[x-1]+n+i+".dat";
File fil = new File(path);

    		fil.delete();

        smt.executeUpdate("insert into storage values('"+enc+"','"+q+"','"+key+"','"+fnm+"',"+i+")");
x++;
        h=1;
  }
// send str to another function and do something with it;
  str1=str.substring((end+1),((int)fileSizeInBytes-1));
String path=a[x-1]+n+i+".txt";
// to store partial files...
store(str1,path);

//to encrypt partial file..............
aes obj=new aes();
        obj.main(key,path,a[x-1]+n+i+".dat");
       
        //For deletion of txt file
 // decrypt obj1=new decrypt();
      //  obj1.main(key,a[i-1]+n+i+".dat",a[i-1]+n+i+".txt");
        String encpath=a[x-1]+n+i+".dat";
        
      
            
smt.executeUpdate("insert into storage values('"+encpath+"','"+a[x-1]+"','"+key+"','"+fnm+"',"+i+")");
      
        System.out.println(str);

   delete();
   } 
  
    
        catch(Exception o)
        {
        
        
       System.out.println(o.getMessage());  
        
        } 
   
   
   }
  
    static void delete()
    {

        
    try{         
                
    }
    catch(Exception obj)
    {
                
     System.out.println(obj.getMessage());           
                
    }            
    
    }
    static void store(String content,String path)
{
try{
 
			File file = new File(path);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();
fw.close();
			System.out.println("Done");
 
		        } catch (IOException e) {
			e.printStackTrace();
		         }

}
    
}
