package simulator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow;

public class SplashWindow3 extends JWindow {
  private int duration;

  public SplashWindow3(int d) {
    duration = d;
  }

  // A simple little method to show a title screen in the center
  // of the screen for the amount of time given in the constructor
  public void showSplash() {
    JPanel content = (JPanel) getContentPane();
    content.setBackground(Color.white);

    // Set the window's bounds, centering the window
    int width = 550;
    int height = 315;
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (screen.width - width) / 2;
    int y = (screen.height - height) / 2;
    setBounds(x, y, width, height);

    // Build the splash screen
      JLabel title = new JLabel("RECURSIVE INFORMATION HIDING STRATEGY..........",
        JLabel.CENTER);
    JLabel title2 = new JLabel("",
        JLabel.CENTER);
   
    JLabel label = new JLabel(new ImageIcon("image1.jpeg"));
    JLabel copyrt = new JLabel("Copyright 2018",
        JLabel.CENTER);
    title.setFont(new Font("Sans-Serif", Font.BOLD, 10));
 title2.setFont(new Font("Sans-Serif", Font.BOLD, 15));
  
    copyrt.setFont(new Font("Sans-Serif", Font.BOLD, 12));
    content.add(title, BorderLayout.NORTH);
    //content.add(title, BorderLayout.);
   
  
    content.add(label, BorderLayout.CENTER);
    content.add(copyrt, BorderLayout.SOUTH);
  
    Color oraRed = new Color(156, 120, 20, 255);
    content.setBorder(BorderFactory.createLineBorder(oraRed, 10));

    // Display it
    setVisible(true);

    // Wait a little while, maybe while loading resources
    try {
      Thread.sleep(duration);
    } catch (Exception e) {
    }

    setVisible(false);
  }

  public void showSplashAndExit() {
    showSplash();
    System.exit(0);
  }

  public static void main(String[] args) {
    // Throw a nice little title page up on the screen first
    SplashWindow3 splash = new SplashWindow3(10000);
    // Normally, we'd call splash.showSplash() and get on with the program.
    // But, since this is only a test...
    splash.showSplash();
  
    Index page=new Index();
    page.setVisible(true);
   
    // page.getContentPane();
  
  
  
  }
}

           
         