package simulator;

import java.awt.*;
import java.awt.image.*;
import java.math.*;

public class ImageData extends Frame
{
  int pix[],h,w,pcount;

  ImageData(String str)
  {
    int i;
    Toolkit tk = Toolkit.getDefaultToolkit();
    Image img  = tk.createImage(str);
    MediaTracker mt = new MediaTracker(this);

    try
    {
      mt.addImage(img,0);
      mt.waitForID(0);
      h = img.getHeight(null);
      w = img.getWidth(null);
      pix = new int[w*h];
      PixelGrabber pg = new PixelGrabber(img,0,0,w,h,pix,0,w);
      if(pg.grabPixels())
         System.out.println("Pixel Collected");
      pcount = h * w;    
    }catch(InterruptedException ie)
    {
      Screen.showMessage("Error : "+ie);
    }
  }

  // To create P value
  public BigInteger getPrime1()
  {
    int fnos[] = Tools.selectFibos(pcount);
    long sum = 0;
    for(int i=0;i<fnos.length;i++)
    {
      int tno =  Math.abs(pix[fnos[i]]);
      sum = sum + tno;
    }
    BigInteger bi = findPrime(sum);
    return(bi);
  }

  // To crete Q value
  public BigInteger getPrime2()
  {
    int pnos[] = Tools.selectPrimes(pcount);
    long sum = 0;
    for(int i=0;i<pnos.length;i++)
    {
      int tno =  Math.abs(pix[pnos[i]]);
      sum = sum + tno;
    }
    BigInteger bi = findPrime(sum);
    return(bi);
  }

  // To find out the next prime number
  public BigInteger findPrime(long no)
  {
    BigInteger bi = new BigInteger(String.valueOf(no));
    BigInteger bone = new BigInteger("1");
    boolean pflag = true;
    while(true)
    {
      if(bi.isProbablePrime(8))
        return(bi);
      bi = bi.add(bone);
    }
  }
}
