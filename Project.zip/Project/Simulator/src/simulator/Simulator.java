package simulator;

import java.io.File;

public class Simulator {

    
    public static void main(String[] args) {
    
        
        File f=new File("c:/temp1/map1.txt");
        
        f.delete();
        
        // TODO code application logic here
    }
}
