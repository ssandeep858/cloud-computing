package simulator;

import java.math.*;

public class Keys
{
  private String PublicKey;
  private String PrivateKey;

  Keys(String ImagePath)
  {
    ImageData idata = new ImageData(ImagePath);
    BigInteger pval = idata.getPrime1();
    BigInteger qval = idata.getPrime2();

    RSAKeyGen rgen = new RSAKeyGen(pval,qval);
    PublicKey  = rgen.getPublicKey();
    PrivateKey = rgen.getPrivateKey();
  }

  // To return the public key value
  public String getPublicKey()
  {
    return(PublicKey);
  }

  // To return the private key value
  public String getPrivateKey()
  {
    return(PrivateKey);
  }
}
