package simulator;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.Vector;

import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
 

public class connect {
       Connection connection;
        Statement smt;
   connect()
   {
       try{
       Class.forName("com.mysql.jdbc.Driver");
		   connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/simulator","root","1234");
	  smt = connection.createStatement();
          ResultSet rs=smt.executeQuery("select * from server");
          String a[]=new String[20];
         int i=0;
          while(rs.next())
          {
          
          a[i]=rs.getString(1);
          i++;
          }
          
          
       }
       catch(Exception obj)
       {
  
       }
   }
   
   
       
}
