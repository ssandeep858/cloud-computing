package simulator;

import java.math.*;
import java.util.*;

class RSAKeyGen
{
  private BigInteger n,e,d;
  private int certainty = 32,radix = 34,bits;
  private BigInteger one = new BigInteger("1");

  // Constructor with P and Q values
  RSAKeyGen(BigInteger p,BigInteger q)
  {
    BigInteger fi_n = fi(p,q);
    n = p.multiply(q);
    e = chooseprimeto(fi_n);
    d = e.modInverse(fi_n);
  }

  // To find out F(n)
  public BigInteger fi(BigInteger prime1,BigInteger prime2)
  {
    return prime1.subtract(one).multiply(prime2.subtract(one));
  }

  // To Convert String into BigInteger
  public BigInteger BI(String s)
  {
    return new BigInteger(s);
  }

  // To Select out the value of e
  BigInteger chooseprimeto(BigInteger f)
  {
    BigInteger tb;

    for(int i=65535;i>=1;i--)
    {
      tb = new BigInteger(""+i);
      if(f.gcd(tb).equals(one))
         return tb;
    }
    return null;
  }

  // Convert BigInteger into String
  public String printBI(BigInteger b)
  {
     return b.toString(radix);
  }

  // To Convert String into BigInteger
  public BigInteger readBI(String s)
  {
     return new BigInteger(s,radix);
  }

  // to return the Public Key Value
  public String getPublicKey()
  {
     return printBI(n)+" "+printBI(e);
  }

  // to return the Private Key Value
  public String getPrivateKey()
  {
    return printBI(n)+" "+printBI(d);
  }
}
