/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

/**
 *
 * @author Administrator
 */
public class size {
    
    public  void main(String filename)
    {
        
        long no_of_files=0;
       File file = new File(filename);

// Get length of file in bytes
long fileSizeInBytes = file.length();
System.out.println(fileSizeInBytes);
if(fileSizeInBytes>200)
{
    no_of_files=fileSizeInBytes/200;
    long d=fileSizeInBytes%200;
    if (d>0)
    {
     no_of_files=no_of_files+1;   
    }
}   
  System.out.println(no_of_files);  
  
  String str="";
  int count=0;
  try {
  Reader fileReader = new BufferedReader(new FileReader(filename));
  String name=file.getName();
  int l=name.length();
  String n=name.substring(0,l-4);
  while (count < fileSizeInBytes)
  { 
    
   str += (char)fileReader.read() ;
   count++;

  }
  String str1="";
  int end=0,i;
  int h=0;
  for ( i=1;i<=no_of_files-1;i++)
  {
      int beg=((i-1)*200+h);
      end=200*i+1;
    str1=str.substring(beg,end);
  
 
  System.out.println(beg); // send str to another function and do something with it;
 System.out.println(end);
String path="c:/"+n+i+".txt";
store(str1,path);
h=1;
  }
  
  
  
 
// send str to another function and do something with it;
  str1=str.substring((end+1),((int)fileSizeInBytes-1));
String path="c:/"+n+i+".txt";
store(str1,path);

  
  
  
  
  
  
  
  
  System.out.println(str);
  } catch (IOException e) {
  // TODO Auto-generated catch block
 }
  
   }
  
    
    static void store(String content,String path)
{
try{
 
			File file = new File(path);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();
 
			System.out.println("Done");
 
		        } catch (IOException e) {
			e.printStackTrace();
		         }

}
}
