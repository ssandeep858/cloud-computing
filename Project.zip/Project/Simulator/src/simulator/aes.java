package simulator;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class aes {
	static Cipher cipher;
	
	public  void main(String key,String path,String filename) {
		
		try {
			//String key="c2bk4xkwdx5h 1ek";
		 
		 SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
			IvParameterSpec ivSpec = new IvParameterSpec(key.getBytes());
			 cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

System.out.print(key);

encrypt(new FileInputStream(path), new FileOutputStream(filename));

		}
		catch (FileNotFoundException e) {
			System.out.println("File Not Found:" + e.getMessage());
			return;
		}
		catch (InvalidAlgorithmParameterException e) {
			System.out.println("Invalid Alogorithm Parameter:" + e.getMessage());
			return;
		}
		catch (NoSuchAlgorithmException e) {
			System.out.println("No Such Algorithm:" + e.getMessage());
			return;
		}
		catch (NoSuchPaddingException e) {
			System.out.println("No Such Padding:" + e.getMessage());
			return;
		}
		catch (InvalidKeyException e) {
			System.out.println("Invalid Key:" + e.getMessage());
			return;
		}

	}

	private static void encrypt(InputStream is, OutputStream os) {

  try {

  	byte[] buf = new byte[1024];

// bytes at this stream are first encoded

  	os = new CipherOutputStream(os, cipher);

// read in the clear text and write to out to encrypt

int numRead = 0;

while ((numRead = is.read(buf)) >= 0) {

    os.write(buf, 0, numRead);

}

os.close();
is.close();
  }

  catch (IOException e) {

  	System.out.println("I/O Error:" + e.getMessage());

  }

    }

	private static void decrypt(InputStream is, OutputStream os) {

  try {

  	byte[] buf = new byte[1024];

// bytes read from stream will be decrypted

  	CipherInputStream cis = new CipherInputStream(is, cipher);

// read in the decrypted bytes and write the clear text to out

int numRead = 0;

while ((numRead = cis.read(buf)) >= 0) {

    os.write(buf, 0, numRead);

}

// close all streams

cis.close();

is.close();

os.close();

  }

  catch (IOException e) {

  	System.out.println("I/O Error:" + e.getMessage());

  }

    }

}