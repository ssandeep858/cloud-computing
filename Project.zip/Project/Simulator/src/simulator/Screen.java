package simulator;


import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;

class Screen
{
  int h,w;

  static int getHeight()
  {
    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension d = tk.getScreenSize();
    return(d.height);
  }

  static int getWidth()
  {
    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension d = tk.getScreenSize();
    return(d.width);
  }

  public static void showMessage(String msg)
  {
    JOptionPane.showMessageDialog(null,msg,"Message"
                                 ,JOptionPane.PLAIN_MESSAGE);
  }

  public static String setFileName(String name)
  {
    int pos = name.lastIndexOf('.');  
    String file = name.substring(0,pos)+".tmp";
    return(file);
  }

  public static void controlSwitch(String fname)
  {
   try
   {
     Runtime r = Runtime.getRuntime();
     Process p = null;
     String str = "attrib "+fname+" +h";
     p = r.exec(str);
     p = null;
     r = null;
    }catch(Exception ie)
     {
       Screen.showMessage("Runtime Error");
     }
  }
}
