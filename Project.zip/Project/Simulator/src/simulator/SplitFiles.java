package simulator;

import java.io.*;
 class SplitFiles {


public static void main(String[] args) {
String str = "";
int count = 0; 
 
try {
  Reader fileReader = new BufferedReader(new FileReader("c:/a.txt"));
  
 
   
  while (count < 5){ 
    
   str += (char)fileReader.read() ;
   count++;

  }
 
  System.out.println(str); // send str to another function and do something with it;

String path="c:/b.txt";
store(str,path);



while (count < 100){ 
    
   str += (char)fileReader.read() ;
   count++;



  }

str=str.substring(6,60);

store(str,"c:/c.txt");


 
 } catch (IOException e) {
  // TODO Auto-generated catch block
 }

//String path="//192.168.1.82/faculty data/abc.txt";


}

static void store(String content,String path)
{
try{
 
			File file = new File(path);
 
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content);
			bw.close();
 
			System.out.println("Done");
 
		        } catch (IOException e) {
			e.printStackTrace();
		         }

}

}
